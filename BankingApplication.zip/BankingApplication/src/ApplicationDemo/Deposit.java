package ApplicationDemo;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.Connection;

/**
 * Servlet implementation class Deposit
 */
public class Deposit extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Deposit() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
       int bal=0;
		
		int Accno =Integer.parseInt(request.getParameter("Accno"));
		int amt=Integer.parseInt(request.getParameter("amount"));
		
		try
		{
			Connection con = (Connection) SystemDB.connect();
			PreparedStatement ps = con.prepareStatement("select * from bankdata where Accno=?");
		
			ps.setInt(1,Accno);
			
			ResultSet rs = ps.executeQuery();
			try
			{
			
				while(rs.next())
				{
				bal = rs.getInt("balance");
				}
				bal = bal+amt;
				
				ps = con.prepareStatement("update bankdata set balance=? where Accno=?");
				ps.setInt(1, bal);
				ps.setInt(2, Accno);
				
				int i = ps.executeUpdate();
				
				if(i>0)
				{
					response.sendRedirect("success.html");
				}
				else
				{
					response.sendRedirect("index.html");
				}
			}catch(SQLException e)
			{
				e.printStackTrace();
			}
			}catch(Exception e)
		{
		e.printStackTrace();
		}
	}

}
