package ApplicationDemo;

import java.io.IOException;
import java.sql.*;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Register
 */
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Register() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	
		int Accno=Integer.parseInt(request.getParameter("Accno"));
		String name=request.getParameter("Name");
		String password=request.getParameter("Password");
		String email =request.getParameter("Email");
		String mobile=request.getParameter("Phone");
		int balance=Integer.parseInt(request.getParameter("Balance"));
		
    	try
		{
		Connection con = SystemDB.connect();
  	    PreparedStatement ps=con.prepareStatement("insert into bankdata values(?,?,?,?,?,?)");
		  ps.setInt(1,Accno);
		  ps.setString(2,name);
		  ps.setString(3,password);
		  ps.setString(4,email);
		  ps.setString(5,mobile);
		  ps.setInt(6,balance);
		
		  int i=ps.executeUpdate();
		  if(i>0)
		  {
			  response.sendRedirect("success.html"); 
		  }
		  else
		  {
			  response.sendRedirect ("index.html");
		  }
	    }
  	catch(SQLException e)
  	{
  		e.printStackTrace();
  	}
 }
		
}


