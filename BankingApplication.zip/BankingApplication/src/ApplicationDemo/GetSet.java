package ApplicationDemo;

public class GetSet 
{
    static String Accno;

	public static String getAccno() {
		return Accno;
	}

	public static void setEmail(String Accno) {
		GetSet.Accno = Accno;
	}
    

    
}
