package ApplicationDemo;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Transfer
 */
public class Transfer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Transfer() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		int newbal=0,oldbal=0,rbal=0,nebal=0;
		int saccno =Integer.parseInt(request.getParameter("Accno"));
	    String password = request.getParameter("password");
		int raccno =Integer.parseInt(request.getParameter("raccno"));
		int amt=Integer.parseInt(request.getParameter("amount"));
		
		try
		{
			Connection con = SystemDB.connect();
			PreparedStatement ps =con.prepareStatement("select * from bankdata where Accno=?");
			ps.setInt(1,saccno);
			ResultSet rs = ps.executeQuery();
			
				while(rs.next())
				{
					oldbal = rs.getInt("balance");
					System.out.println(""+oldbal);
				}
			
				PreparedStatement ps2 =con.prepareStatement("select * from bankdata where Accno=?");
				ps2.setInt(1,raccno);
				
				ResultSet rs1 = ps2.executeQuery();
				
				    while(rs1.next())
					{
						rbal = rs1.getInt("balance");
						System.out.println(""+rbal);
					}
				    
				if(amt<oldbal )
				{
					newbal = oldbal-amt;
					System.out.println(""+newbal);
					
					PreparedStatement p= con.prepareStatement("update bankdata set balance=? where Accno=?");
					p.setInt(1, newbal);
					p.setInt(2, saccno);
					
					int i = p.executeUpdate();
					
						if(i>0)
						{
							nebal=rbal+amt;
						}
						else
						{
							response.sendRedirect("failed.html");
						}
						
						
						 System.out.println(newbal);
						    
					    	PreparedStatement ps3 = con.prepareStatement("update bankdata set balance=? where Accno=?");
							ps3.setInt(1, nebal);
							ps3.setInt(2, raccno);
							ps3.executeUpdate();
							
							int j = ps3.executeUpdate();
							
							if(j>0)
							{
									response.sendRedirect("success.html");
							}
							else
							{
								response.sendRedirect("failed.html");
							}
						
				}
				else
				{
					response.sendRedirect("failed.html");
				}
				
				
		}	
				catch(Exception e)
			{
				e.printStackTrace();
			}
		
	}
		
	}
	


	


