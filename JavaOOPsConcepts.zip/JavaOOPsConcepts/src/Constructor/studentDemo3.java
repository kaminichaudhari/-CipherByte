package Constructor;

public class studentDemo3 {
	int age;
	String name;
	String city;
	
	static{
		System.out.println("Static Block");
	}
	public studentDemo3(){
		System.out.println("Demo2 class Constructor");
	}
	{
		System.out.println("Instance Block");
	}
	public static void main(String args[])
	{
		studentDemo3 d1=new studentDemo3();

	//	Demo2 d3=new Demo2();
		
	}

}
