package Constructor;

public class student {
	
	int rollNO;
	String name;
	String city;
	int age;
	
	public student(){//create constructor
		super();
		System.out.println("student class constructor");
	}
	public static void main(String args[])
	{
		student s1=new student();
	}
	

}
/*Constructor : The main aim of constructor is to initialize object.
Constructor name is same as class name.
Each class has constructor if we write or not.
Constructor doesnt conatin return type.
Constructor is called automatically when we create Object.
Every construtor has super keyword as first line if we write or not.


Note : Constructor is used to initialize an object .
new keyword is used to create object.*/