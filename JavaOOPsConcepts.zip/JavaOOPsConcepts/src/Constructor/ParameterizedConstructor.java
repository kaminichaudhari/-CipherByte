package Constructor;

public class ParameterizedConstructor {
	int age;
	String name;
	String city;
	
	public ParameterizedConstructor(int age,String name,String city)//Parameterized Constructor: A constructor that accepts parameters to 
	                                                                  //initialize an object with specific values.

	{
		 super();
		 this.age=age;
		 this.city=city;
		 this.name=name;
		 
	}
	public static void main(String args[])
	{
		ParameterizedConstructor p1=new ParameterizedConstructor(21,"kamini","shahada");
		System.out.println(p1.name);
		System.out.println(p1.age);
		System.out.println(p1.city);
	}

}

