package Constructor;

public class studentDemo4 {
	int rollNo;
	String name;
	int age;
	
	static{
		System.out.println("static block 1");
	}
	public studentDemo4(){
		System.out.println("StudentDemo4 class constructor");
	}
	{
		System.out.println("Instance Block 1");
	}
	
	static{
		System.out.println("Static Block 2");
		
	}
	{
		System.out.println("Instance Block 2");
	}
	public static void main(String args[])
	{
		studentDemo4 d1=new studentDemo4();
	}
	

}
