package Constructor;

public class DefaultConstructore //1)Default Constructor: 
	                             //2)A constructor provided by Java if no constructor is explicitly defined.
	                             //3) It initializes the object with default values (e.g., null for objects, 0 for integers, etc.).
{
      int age;
      String name;
      String city;
      
      public static void main(String args[])
      {
    	  DefaultConstructore d1=new DefaultConstructore();
    	  System.out.println(d1.age);
    	  System.out.println(d1.city);
    	  System.out.println(d1.name);
      }
}
