package Constructor;

public class StudentDemo {
	int age;
	String name;
	String city;
	
	public StudentDemo(){
		System.out.println("Student Demo class is constructor");
	}
	{
		System.out.println("Instance Block");
	}
	public static void main (String args[])
	{
		StudentDemo s1=new StudentDemo();
	
	}

}
