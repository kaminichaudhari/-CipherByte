package MethodCalling1;

public class Demo2 {
           public void m2(){
        	   System.out.println("m2 method in Demo2 Class");
           }
           public static void main(String args[])
           {
        	   Demo2 d2=new Demo2();
        	   d2.m2();
           }
}
