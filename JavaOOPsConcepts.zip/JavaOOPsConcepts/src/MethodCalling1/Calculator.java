package MethodCalling1;

import java.util.Scanner;

public class Calculator {
   
	public void c1(){
		  
		  Scanner sc=new Scanner(System.in);
          int num1=sc.nextInt();
		   int num2=sc.nextInt();
			 System.out.println("Addition:"+(num1+num2));
			 System.out.println("subtraction:"+(num1-num2));
			 System.out.println("multiplication:"+(num1*num2));
			 System.out.println("division:"+(num1/num2));
			
	  }
	  public static void main(String args[])
	  {
		  System.out.println("Enter number:");
	 
		  Calculator p= new Calculator();
		 p.c1();
	  }	  
}

