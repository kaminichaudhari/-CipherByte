package MethodCalling1;

public class Test2 {
	public void m2(){
		System.out.println("m2 method of test2 class");
	}
	public static void main (String args[]){
		Test2 t2=new Test2();
		t2.m2();
		
	/*	Test1 t1=new Test1();   //MethodCallingSameAndDiffrentPackage 
		t1.m1();*/
	}

}
