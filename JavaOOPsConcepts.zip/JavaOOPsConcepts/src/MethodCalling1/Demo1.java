package MethodCalling1;

public class Demo1 {
             public void  m1(){
            	 System.out.println("M1 method in Demo1 class");
             }
             public static void main(String args[])
             {
            	 Demo1 d1=new Demo1();
            	 d1.m1();
             }
}
