package MethodCalling1;



public class methodDemo {
	public static  void twoNoAdd() {
		int a = 10;
		int b = 20;
		int c = a + b;
		System.out.println(c);
	}
	
	public static void twoNoSub() {
		int a = 10;
		int b = 20;
		int c = a - b;
		System.out.println(c);
	}
	public static void twoNoMul() {
		int a = 10;
		int b = 20;
		int c = a * b;
		System.out.println(c);
	}
	public static void twoNoDiv() {
		int a = 10;
		int b = 20;
		int c = a / b;
		System.out.println(c);
	}

	public static void main(String[] args) {

		methodDemo.twoNoAdd();
		methodDemo.twoNoSub();
		methodDemo.twoNoMul();
		methodDemo.twoNoDiv();
	}
}


