package MethodCalling1;

public class Test1 {                           //MethodCallingSameAndDiffrentPackage 
             public void m1(){
            	 System.out.println("m1 Method of test1 class");
             }
             public static void main(String args[]){
            	 Test1 t1=new Test1();
            	 t1.m1();
             }
}
