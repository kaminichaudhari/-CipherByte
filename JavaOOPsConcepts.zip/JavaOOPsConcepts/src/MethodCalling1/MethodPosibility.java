package MethodCalling1;



public class MethodPosibility {
	 
			public void add(){                                 //1)Method will not take parameter and will not return result.
				int a=10;
				int b=5;
				int c=a+b;
				System.out.println(c);
			}
			
			public void mul(int a ,int b)                    //2) Method will take parameter and will not take return result.
			{
				int c=a*b;
				System.out.println(c);
				
			}
			
			public int sub()                                 //3) method will not take parameter and will take return result.
			{
				int a=20;
				int b=30;
				int c=a-b;
				//System.out.println(c);
				return c;
			}
			
			public int add1(int a,int b)                     //4) method will take parameter and will take return result.
			{
				int c=a+b;
				return c;
			}
			
			public static void mul1()                    //5) using static 
			{
				int a=5;
				int b=3;
				int c=a*b;
				System.out.println(c);
			}
			
			public static int sub1(int a,int b)          //6)static method will take parameter and will take return result.
			{
			    int	c=a-b;
			    System.out.println(c);
				return c;
			}
			
			public static void addition(int a,int b)     //7)static method will take parameter and will not take return result.
			{
				  int c=a+b;
				  System.out.println(c);
			}
			
			public static int subtraction()               //8)static method will  not take parameter and will  take return result.
			
			{
				int a=45;
				int b=5;
				int c=a-b;
				System.out.println(c);
				return c;
			}
			
			public static void main(String args[])
			{
				MethodPosibility a=new MethodPosibility();           //1) create obj and initialize
				a.add();
				
				MethodPosibility m=new MethodPosibility();           //20
				m.mul(10, 10);
				
				MethodPosibility s=new MethodPosibility();          //3)
				//s.sub();
				int result=s.sub();
				System.out.println(result);
				
				MethodPosibility a1=new MethodPosibility();          //4)
				int result1= a1.add1(50, 50);
				System.out.println(result1);
				
				MethodPosibility.mul1();                       //5) class name and object
				
				MethodPosibility.sub1(30, 8);                  //6)
				
				MethodPosibility.addition(76, 15);             //7)
				
				MethodPosibility.subtraction();                //8)
				
				
			}

}
