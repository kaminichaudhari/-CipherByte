package MethodCalling2;

import MethodCalling1.Demo1;
import MethodCalling1.Demo2;

public class Demo3 {
             public void m3(){
            	 System.out.println("M3 method in Demo3 Class");
             }
             public static void main(String args[])
             {
            	 Demo3 d3=new Demo3();
            	 d3.m3();
            	 
            	 Demo2 d2 =new Demo2();
            	 d2.m2();
            	 
            	 Demo1 d1=new Demo1(); 
            	 d1.m1();
            	 
             }
}
