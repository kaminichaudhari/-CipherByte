package MethodCalling2;

import MethodCalling1.Test1;
import MethodCalling1.Test2;

public class Test3 {
         public void m3(){
        	 System.out.println("t3 method of test3 class");
         }
         public static void main(String args[]){
        	 Test3 t3=new Test3();
        	 t3.m3();
        	 
        	 Test1 t1=new Test1();        //access test1 method in methodcalling1 package
        	 t1.m1();
        	 
        	 Test2 t2=new Test2();
        	 t2.m2();
         }
}
