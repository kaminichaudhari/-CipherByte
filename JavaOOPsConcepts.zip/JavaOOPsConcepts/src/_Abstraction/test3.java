package _Abstraction;

public abstract class test3 
{
        public void m1(){
        	System.out.println("m1 method of test3 class");
        	
        	//test3 t=new test3();
        	test3.m3();
        }
        
        public abstract void m2();
        
        public static void m3(){
        	System.out.println("m2 method of Test3 class");
        } 
        
        public static void main(String args[]){
        	//test3 t=new test3();  //no object create abstract class
        	test3.m3();//call static method
        	
        	
        }
}
