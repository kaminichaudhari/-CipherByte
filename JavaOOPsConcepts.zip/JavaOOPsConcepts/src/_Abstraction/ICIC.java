package _Abstraction;

public  class ICIC extends SBI {
	
	@Override
	public void withdraw(){
		System.out.println("withdraw logic by ICIC");
	}
	
	
	public void deposit(){
		System.out.println("diposit logic by ICIC");
		
	}

	public static void main(String args[]){
		ICIC I=new ICIC();
		I.deposit();
		I.withdraw();
		I.reporate();
		
		SBI s=new RBI();
		s.deposit();
		s.withdraw();
		s.reporate();
		
	}


	
}
