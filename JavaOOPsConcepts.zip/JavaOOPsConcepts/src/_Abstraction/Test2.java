package _Abstraction;

public class Test2 extends Test {
	
	@Override
	public void m2(){
		
		System.out.println("this is a body definition of abstract method m2 of Test class ");
		
	}
	public static void main(String args[]){
		Test2 t=new Test2();
		t.m1();
		t.m2();
	}

}
