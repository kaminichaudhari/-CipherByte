package _Abstraction;

public  class RBI extends SBI {
	
	@Override
	public void withdraw(){
		System.out.println("withdraw logic by SBI");
	}
	@Override
	public void deposit(){
		System.out.println("diposit logic by SBI");
	}
	
	public static void main(String args[]){
		RBI r =new RBI();
		r.withdraw();
		r.deposit();
		r.reporate();
		
		SBI s=new RBI();
		s.deposit();
		s.withdraw();
		s.reporate();
	}
	

}
