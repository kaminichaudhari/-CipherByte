package _Abstraction;

public abstract class Test {
	
	public void m1(){//non abstract method
		System.out.println("m1 method of test  class");
		
		
	}
	public abstract  void m2(); // abstract method
	
	
	public static void main(String args[]){
	    //Test t1=new Test();  //We cant create object of abstract class.
	    
	}

}
