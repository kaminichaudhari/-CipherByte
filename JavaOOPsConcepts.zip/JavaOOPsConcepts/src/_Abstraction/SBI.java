package _Abstraction;

public abstract class SBI {
	
	public  abstract void withdraw();
	public abstract void deposit();
	public void reporate(){
		System.out.println("reporate is 8%");
	}

}
