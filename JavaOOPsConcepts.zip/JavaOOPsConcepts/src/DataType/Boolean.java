package DataType;

public class Boolean {
	public static void main(StringDemo args[])
	{
		boolean b=true;
		boolean c=false;
		//boolean c1=kajjs;//error
		System.out.println(b);
		System.out.println(c);
		
	}

}
