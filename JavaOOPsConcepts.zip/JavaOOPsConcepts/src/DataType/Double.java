package DataType;

public class Double {
	public static void main(StringDemo args[])
	{
		double d=123.366553674888884d;
		System.out.println(d);
		double s=1234.36652524364488834453d;
		System.out.println(s);
	}

}
