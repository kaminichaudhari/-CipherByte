package DataType;

public class Short 
{
   public static void main(StringDemo args[])
   {
	 short a= -32223; //range -32768 to 32767
	//short a1=-43567;//error
	 short a2= 31244;
	  //short a3= 32768;//error
	 System.out.println(a);
	 //System.out.println(a1);
	  System.out.println(a2);
	  //System.out.println(a3);
	  
   }
}
