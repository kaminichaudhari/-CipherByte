package DataType;

public class Int 
{
	public static void main(StringDemo args[]){
		
	
   int  a=10;
   int b= 28;
   int c=a+b;
  
 System.out.println("Addition of two number:"+c);
}
}