package DataType;

public class Char {
	public static void main(StringDemo args[])
	{
		char a='k';
		System.out.println(a);
		
		char a1='s';
		System.out.println(a1);
		
	}

}
