package DataType;

public class Byte {
	public static void main(StringDemo args[])
	{
		byte b= -128;//range is -128 to 127
		//byte b1=-129; //error
		byte b2= 127;
		//byte b3= 128;//error
		System.out.println(b);
		System.out.println(b2);
	}
	

}
