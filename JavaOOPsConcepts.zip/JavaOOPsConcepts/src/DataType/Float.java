package DataType;

public class Float 
{
	public static void main(StringDemo args[])
	{
     float a=76.55111f;
     float b=-544.76543f;
     float c=a+b;
     System.out.println(c);
}
}