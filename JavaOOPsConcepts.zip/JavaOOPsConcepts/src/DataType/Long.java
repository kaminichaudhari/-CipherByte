package DataType;

public class Long {
	public static void main(StringDemo args[])
	{
		long a=5000l;
		long a1=765543654765433L;
		
		System.out.println(a1);
		
	}

}
