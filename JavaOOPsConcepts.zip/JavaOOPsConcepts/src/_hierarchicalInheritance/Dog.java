package _hierarchicalInheritance;

public class Dog extends Animal{
	
	void bark(){
		System.out.println("the dog bargs");
	}
	public static void main(String args[]){
		Dog d=new Dog();
		d.bark();//dog class
		d.eat();//animal class
	}

}
