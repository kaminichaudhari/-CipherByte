package _hierarchicalInheritance;

public class Lion extends Animal {
      void roar(){
    	  System.out.println("the Lion roars");
      }
      public static void main(String args[]){
    	  Lion l=new Lion();
    	  l.eat();//animal class
    	  l.roar();//lion class
      }
}
