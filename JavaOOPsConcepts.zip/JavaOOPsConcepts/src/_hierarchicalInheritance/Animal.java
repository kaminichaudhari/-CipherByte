package _hierarchicalInheritance;

public class Animal {
	void eat(){
		System.out.println("Animal eat food");
	}

}
