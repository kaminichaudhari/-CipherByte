package Inteface;

public interface A {
	public abstract void m1();
	
	 public void m2();  //Interface methods are bydefault public and abstract.


		
	}
	

//we can not take non abstract methods in interface.

/*public interface A {
	public abstract void m1();
	
	 public void m2(){
		 
	 }    


		
}*/
/*public interface A{
	
	public static final int a=72; //3)Interface variables are bydefault public static and final.

	int b=23;
	public static void main(String args[]){
		A a1=new A();             //4)we cant't create obj of interface
		
	}
	}
	*/
	

	