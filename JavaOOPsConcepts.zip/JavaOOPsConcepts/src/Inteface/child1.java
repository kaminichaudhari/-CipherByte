package Inteface;

public class child1 implements ParentDemo,Animal{//multiple Inheritance 

	@Override
	public void animalSound() {
		System.out.println("lion is roar");
   }

	@Override
	public void sound() {
		System.out.println("Dog Barks");

		
	}
     public static void main(String args[]){
    	 child1 c=new child1();
    	 c.animalSound();
    	 c.sound();
     }
	

}
