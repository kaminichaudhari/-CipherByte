package Inteface;

interface ParentDemo {
	void animalSound();

}
