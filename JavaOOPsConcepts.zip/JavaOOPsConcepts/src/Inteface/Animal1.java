package Inteface;

public interface Animal1 {
	void sound();

}
