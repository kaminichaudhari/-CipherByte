package Inteface;

public class Lion implements Animal1 {

	@Override
	public void sound() {
		// TODO Auto-generated method stub
		System.out.println("lion is roar");
		
	}
	public static void main(String args[]){
		Lion l=new Lion();
		l.sound();
		
	//	Lion l1=new Animal1();
		
		Animal1 a=new Lion();
		a.sound();
	}

}
