package Inteface;

public interface Animal {
	void sound();
	

}
