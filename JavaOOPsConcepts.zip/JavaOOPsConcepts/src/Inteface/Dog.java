package Inteface;

public class Dog implements Animal{

	@Override
	public void sound() {
		// TODO Auto-generated method stub
		System.out.println("Dog Barks");
		
	}
	public static void main(String args[])
	{
		Dog d=new Dog();
		d.sound();
	}

}
