package WrapperClassDemo;

public class WrapperDemo {
	public static void main(String[] args) {
		

	String s="Kamini";
	String s1=new String(s);
   // int a=new int (20);
	
	Integer a=new Integer(30);
	Integer a1=new Integer(40);
	System.out.println(a+a1);
	
	int i=10;
	Integer a3=i;
	
	Integer a4=Integer.parseInt("10");//primitive to Wrapper
	System.out.println("a="+a+" a1="+a1);
	System.out.println("a3="+a4+" a4="+a4);
	
	Integer a5=Integer.valueOf(50);  //primitive to wrapper
	System.out.println(a5);
	
	
	
	//System.out.println(a);
	

}
}