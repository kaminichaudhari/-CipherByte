package WrapperClassDemo;
//Wrapper Class: Represent primitive Data in object format.
public class WrapperClassDemo1 {
	public static void main(String args[]){
		byte b=20;                         //primitive Data
		System.out.println(b);
		
		Byte b1=new Byte(b);               //Primitive Convert into object
		System.out.println(b);             //Auto-Boxing
		
		byte b2=b;                         //Convert Object into Primitive
		System.out.println(b);             //Auto-un-boxing
	
		
		/*int a=10;
		System.out.println(a);
		
		Integer a1=new Integer(a);
		System.out.println(a1);
		
		int a2=a;
		System.out.println(a2);*/
	}

}
