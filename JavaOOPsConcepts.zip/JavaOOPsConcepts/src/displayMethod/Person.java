package displayMethod;

public class Person {
	
	private int age;
	private String name;
	private String city;
	
	 public void display(){
		 System.out.println(age);
		 System.out.println(name);
		 System.out.println(city);
	 }
	public static void main(String args[])
	{
	  Person p1=new Person();
	  p1.age=21;
	  p1.name="kamini";
	  p1.city="Shahada";
	 /*  System.out.println(p1.age);
	  System.out.println(p1.name);
	  System.out.println(p1.city);*/
	  p1.display();
	  
	  Person p2=new Person();
	  p2.age=23;
	  p2.name="neha";
	  p2.city="shirpur";
	  /* System.out.println(p2.age);
	  System.out.println(p2.name);
	  System.out.println(p2.city);*/
	  p2.display();
	  
	  Person p3=new Person();
	  p3.age=24;
	  p3.name="priya";
	  p3.city="pune";
	  p3.display();
		
	}

}
