package displayMethod;

public class student {
	private String name;
	private int age;
	private String city;
	
	public String display(){
		return age + " "+ name + " " + city +" "; //"student[age="+age+"name="+name+"city="+city+"]";
		
	}
	public static void main(String args[]){
		student s1=new student();
		s1.age=21;
		s1.city="shahada";
		s1.name="kamini";
		System.out.println(s1.display());
				
	}

}
