package Encapsulation;

public class Student1 {
	public static void main(String args[]){
		Student s=new Student();
	     s.setage(22);
	     s.setcity("shahada");
	     s.setname("kamini");
	     
	     Student s1=new Student();
	     s1.setage(23);
	     s1.setcity("Dhule");
	     s1.setname("neha");
	     
		
	System.out.println(s.getname());
	System.out.println(s.getage());
	System.out.println(s.getcity());
	System.out.println(s.toString());//toString Method
	System.out.println(s1.toString());
	
	
	}

}
