package Encapsulation;

public class Student {
	private String name;
	private int age;
	private  String city;
	
	public String getname(){
		return name;
		
	}
	public void setname(String name){
		this.name=name;
		
	}
	public int getage(){
		return age;
		
	}
	public void setage(int age){
		this.age=age;
	}
	public String getcity(){
		return city;
		
	}
	public void setcity(String city){
		this.city=city;
		
	}
	@Override
	public String toString(){   //to String Method
		return "Student[name "+ name +" age "+ age +" scity "+ city +"]";
		
	}

}
