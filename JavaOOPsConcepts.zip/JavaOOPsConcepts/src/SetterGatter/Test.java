package SetterGatter;

public class Test {
	public static void main(String args[])
	{
		student s1=new student();
		s1.setrollno(11);
		s1.setname("kamini");
		s1.setcity("shahada");
		
		System.out.println(s1.getrollno());
		System.out.println(s1.getname());
		System.out.println(s1.getcity());
		
		student s2=new student();
		s2.setrollno(12);
		s2.setname("swati");
		s2.setcity("pune");
		
		System.out.println(s2.getrollno());
		System.out.println(s2.getname());
		System.out.println(s2.getcity());
		
	}
	

}
