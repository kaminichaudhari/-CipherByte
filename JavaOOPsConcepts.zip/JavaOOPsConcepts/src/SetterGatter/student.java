package SetterGatter;

public class student {
	private int rollno;
	private String name;
	private String city;
	
	/*public static void main(String args[])
	{
		student s1=new student();
		s1.city="shahada";
		System.out.println(s1.city);
		
	}*/
	public int getrollno(){
		return rollno;
	}
	public void setrollno(int rollno){
		this.rollno=rollno;
	}
	public String getname(){
		return name;
		
	}
	public void setname(String name){
		this.name=name;
		
	}
	public String getcity(){
		return city;
		
	}
	public void setcity(String city){
		this.city=city;
	}
	
}
