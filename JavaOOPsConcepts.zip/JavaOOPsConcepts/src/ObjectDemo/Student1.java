package ObjectDemo;



public class Student1 {
	int rollNo;
	String name;
	String email;
	int age;
	
	public static void main (String args[])
	{
		Student1 stud=new Student1();
		stud.rollNo=12;
		stud.name="neha";
		stud.email="chaudharineha@gmail.com";
		stud.age=21;
		
		System.out.println(stud.rollNo);
		System.out.println(stud.name);
		System.out.println(stud.email);
		System.out.println(stud.age);
		
		Student1 stud2=new Student1();

		stud.rollNo=16;
		stud.name="nikita";
		stud.email="nik121@gmail.com";
		stud.age=23;
		System.out.println(stud.rollNo);
		System.out.println(stud.name);
		System.out.println(stud.email);
		System.out.println(stud.age);
		
	}
	

}
