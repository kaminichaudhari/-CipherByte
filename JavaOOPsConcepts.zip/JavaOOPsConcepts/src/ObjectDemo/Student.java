package ObjectDemo;

public class Student {     //Object : It means seperate copy of memory.

	  int rollNo;          //syntax : ClassName refName=new ClassName();
      String name;
      String city;
     
     public static void main(String args[])
     {
    	 Student s1=new Student();
    	 s1.rollNo=12;
    	 s1.name="kamini";
    	 s1.city="shahada";
    	 System.out.println(s1.rollNo);
    	 System.out.println(s1.name);
    	 System.out.println(s1.city);
    	 
     }
   
}
