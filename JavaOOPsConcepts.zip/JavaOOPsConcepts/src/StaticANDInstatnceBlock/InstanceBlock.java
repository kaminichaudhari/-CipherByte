package StaticANDInstatnceBlock;

public class InstanceBlock {            //1) Instance Block: It is similar to method which has no name.
                                      //  It is executed when an object of the class is created.
	{
		System.out.println("Instance Block");
	}
	public static void main(String args[])
	{
		InstanceBlock a1=new InstanceBlock();
	}

}
