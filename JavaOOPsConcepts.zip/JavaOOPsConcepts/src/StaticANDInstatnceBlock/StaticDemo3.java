package StaticANDInstatnceBlock;

public class StaticDemo3 {
     static
     {
	        System.out.println("Static Block");
     }
     
     {
    	 System.out.println("Instance Block");
     }
     public static void main(String args[])
     {
    	 StaticDemo3 d1=new StaticDemo3();
    	// StaticDemo3 d2=new StaticDemo3();
    	// StaticDemo3 d3=new StaticDemo3();
     }
     
}
