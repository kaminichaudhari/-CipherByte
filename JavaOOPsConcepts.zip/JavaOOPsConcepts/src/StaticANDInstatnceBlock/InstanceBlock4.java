package StaticANDInstatnceBlock;

public class InstanceBlock4 {
	{
		System.out.println("Inastance Block");
	}
	public static void main(String args[])
	{
		InstanceBlock4 m1=new InstanceBlock4();
		InstanceBlock4 m3=new InstanceBlock4();
		InstanceBlock4 m2=new InstanceBlock4();
	}

}
