package StaticANDInstatnceBlock;

public class InstanceBlock2 {
	{
		System.out.println("Instance Block 1");
	}
	{
		System.out.println("Instatnce Block 2");
	}
	
	public static void main(String args[])
	{
		InstanceBlock2 s1=new InstanceBlock2();
		//InstanceBlock2 s2=new InstanceBlock2();
		//InstanceBlock2 s3=new InstanceBlock2();
		
	}

}
