package StaticANDInstatnceBlock;

public class StaticDemo {
	static{
		System.out.println("static Block");
	}
	public static void main(String args[])
	{
		
	}

}
