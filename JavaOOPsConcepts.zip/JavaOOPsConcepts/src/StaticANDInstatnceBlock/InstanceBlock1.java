package StaticANDInstatnceBlock;

public class InstanceBlock1 {
	{
		System.out.println("Instance Block");
	}
	public void m1(){
		System.out.println("m1 method OF InstanceBlock1 class");
	}
	public static void main(String args[])
	{
		InstanceBlock1 s1=new InstanceBlock1();
	    s1.m1();
	}

}
