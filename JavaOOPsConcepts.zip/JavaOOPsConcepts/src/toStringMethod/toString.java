package toStringMethod;

public class toString {
	int id;
	String name;
	public static void main(String args[]){
		
		toString s=new toString();
		s.id=101;
		s.name="kamini";
		System.out.println(s);
		System.out.println(s.toString());
		
		
	}
	/*@Override
	public String toString()
	{
		return id+"--"+name;
		
	}*/
}
