package toStringMethod;

public class Person1 {
	public static void main(String args[]){
		Person p2=new Person(23,"nisha","shahda");
		System.out.println(p2);
		p2.setAge(24);
		p2.setCity("dhule");
		
		System.out.println(p2.getAge());
		System.out.println(p2.getCity());
		System.out.println(p2);
		
		
	}

}
