package toStringMethod;

public class Student {
	private String name;
	private int rollno;
	private String city;
	
	@Override
	public String toString(){
		return "Student[ name= " + name+ " rollno= "+rollno+ " city = " + city + "]";
		
	}
	public static void main(String arhs[])
	{
		Student s1=new Student();
		s1.name="Kamini";
		s1.rollno=97;
		s1.city="shahada";
		
		System.out.println(s1);
	}

}
