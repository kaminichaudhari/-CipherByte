package AccessModifier;

public class PublicClass {

 	String name="Neha";
 	
 	public void Name(){
 		System.out.println("Neha is a girl");
 	}
 	public static void main(String args[])
 	{
 		PublicClass P=new PublicClass();
 		P.Name();
 	}
}
