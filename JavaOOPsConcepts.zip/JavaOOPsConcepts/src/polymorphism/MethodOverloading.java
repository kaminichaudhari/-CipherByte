package polymorphism;

public class MethodOverloading {
	
	public void add(int a,int b){
		int d=a+b;
		System.out.println(d);
	}
	public void add(int a, int b, int c){
		int f=a+b+c;
		System.out.println(f);
	}
	
	public static void main(String args[])
	{
		MethodOverloading m = new MethodOverloading ();
		m.add(20, 10);
		m.add(20, 10, 10);
	}

}
