package polymorphism;

public class methodOverloading3 {
	
	public int add(int a,int b){
		int d=a+b;
		return d;
	}
	
	public void add(int a,int b,int c){
		int f=a+b+c;
		System.out.println(f);
	}
	public static void main(String args[])
	{
		methodOverloading3 m1=new methodOverloading3();
		m1.add(10, 20, 30);
		int a=m1.add(10, 20);
		System.out.println(a);
	}

}
