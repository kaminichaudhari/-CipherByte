package polymorphism;

public class methodoverridingParent {
	public void m1(){
		System.out.println("Hello from parent class");
	}

}
