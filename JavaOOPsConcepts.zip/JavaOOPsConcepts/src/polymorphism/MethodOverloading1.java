package polymorphism;

public class MethodOverloading1 
{
    public void print(String fname,String lname){
    	System.out.println(fname);
    	System.out.println(lname);
    }
    public void print(String add, int age)
    {
    	System.out.println(add);
    	System.out.println(age);
    }
    public static void main(String args[]){
    	MethodOverloading1 m=new MethodOverloading1();
    	m.print("shahada", 21);
    	m.print("kamini","chaudhari");
    }
}
