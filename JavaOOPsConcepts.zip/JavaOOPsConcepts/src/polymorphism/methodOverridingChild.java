package polymorphism;

public class methodOverridingChild extends methodoverridingParent{
	
	@Override
	public void m1(){
		System.out.println("welcome to child class");
		
	}
	
	public static void main(String args[]){
		methodOverridingChild p=new methodOverridingChild();
		p.m1();
	}
	
	

}
