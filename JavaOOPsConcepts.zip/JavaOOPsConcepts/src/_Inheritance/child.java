package _Inheritance;

public class child extends Parent{           //Inheritance:When we want to access all the properties of one class into another class
                                             //then we should go for inheritance .
	
	public void m2(){
		System.out.println("m2 method of parent child class");
	}
	public static void main(String args[]){
		child c=new child();
		c.m1();
		c.m2();
		
		
	}

}
