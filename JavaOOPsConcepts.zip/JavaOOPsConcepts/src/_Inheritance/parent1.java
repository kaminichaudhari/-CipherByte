package _Inheritance;

public class parent1 {
	public void a1(){
		System.out.println("a1 method of parent 1 class");
	}

}
