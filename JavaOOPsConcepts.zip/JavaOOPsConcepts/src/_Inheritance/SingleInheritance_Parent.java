package _Inheritance;

public class SingleInheritance_Parent {
	public void m1(){
		System.out.println("m1 method of Single Inheritance parent class");
	}
	
	public void m2(){
		System.out.println("m2 method of parent class");
	}
	
	public void m3(){
		System.out.println("m3 method of parent class");
	}
	

}
