package _Inheritance;

public class child1 extends parent1{
	public void a2(){
		System.out.println("a2 method of child 1 class");
	}
	public static void main(String args[]){
		child1 c1=new child1 ();
		c1.a1();       //parent class
		c1.a2();       //child class
		
		parent1 p=new child1();  
		p.a1();
		//p.a2();
		
		//child1 c=new parent1();
		
	}

}
