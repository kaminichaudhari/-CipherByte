package _Inheritance;

public class singleInheritance_child extends SingleInheritance_Parent {
	
	public void m4(){
		System.out.println("m4 method of child class");
	}
	
	public static void main(String args[]){
		singleInheritance_child c=new singleInheritance_child();
		c.m1();
		c.m2();
		c.m3();
		c.m4();
		SingleInheritance_Parent p=new SingleInheritance_Parent();
		p.m1();
		p.m2();
		p.m3();
		
		SingleInheritance_Parent p1=new singleInheritance_child();
		p1.m1();
		p1.m2();
		p1.m3();
		//singleInheritance_child c1=new SingleInheritance_Parent();
		
	}

}
