package ScannerClass;

import java.util.Scanner;

public class AdditionUseScanner {
	public static void main(String args[])            //Float value
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter first number:");
		float a=sc.nextFloat();
		System.out.println("Enter second number:");
		float b=sc.nextFloat();
		
		float c=a+b;
		System.out.print("Addition of two number:"+c);
	}
	/*{
		Scanner sc=new Scanner(System.in);               // integer value
			System.out.println("Enter first number:");
			int a=sc.nextInt();
			System.out.println("Enter second number:");
			int b=sc.nextInt();
			
			int c= a*b;
			System.out.print("Multiplication of two number:"+c);
	}*/
	/*{
		Scanner sc=new Scanner(System.in);              
		System.out.println("Enter first number:");        // Long value
		long a=sc.nextLong();
		System.out.println("Enter second number:");
		long b=sc.nextLong();
		
		long c= a*b;
		System.out.print("Multiplication of two number:"+c);
	}*/
	/*{
		Scanner sc=new Scanner(System.in);               // Double value
	    System.out.println("Enter first number:");
	    Double a=sc.nextDouble();
	    System.out.println("Enter second number:");
	    Double b=sc.nextDouble();
	
	    Double c= a-b;
	    System.out.print("Subtraction of two number:"+c);
	}*/
	/*{
		Scanner sc=new Scanner(System.in);               // integer value
		System.out.println("Enter first number:");
		char a=sc.next().charAt(0);
		System.out.println("Enter second number:");
		char b=sc.next().charAt(0);
		
		char c= (char) (a+b);
		System.out.print("Addition of two number:"+c);
	}*/
}
