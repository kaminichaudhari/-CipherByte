package ScannerClass;

import java.util.Scanner;

public class booleanDemo {
	 public static void main(String args[])
	    {
		   Scanner sc=new Scanner(System.in);
		   System.out.println("Enter the number:");
		    boolean a= sc.nextBoolean();//use for true or false
		    System.out.println(a);
		}
	
}
