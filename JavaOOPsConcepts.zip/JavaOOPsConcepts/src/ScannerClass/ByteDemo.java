package ScannerClass;

import java.util.Scanner;

public class ByteDemo {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter first number:");
		byte a=sc.nextByte();//
		System.out.println(a);
		
       
	}

}
