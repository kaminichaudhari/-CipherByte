package ScannerClass;

import java.util.Scanner;

public class shortDemo 
{
   public static void main(String args[])
    {
	   Scanner sc=new Scanner(System.in);
	   System.out.println("Enter the number:");
	    short a= sc.nextShort();
	    System.out.println(a);
	}
}
