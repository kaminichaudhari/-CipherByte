//Identifier: In java Identifier is the name of the class,name of the method, name of the variable which is used for the
              //identification purpose is called as identifier.

package ScannerClass;

public class Addition 
{
     public static void main(String args[])
     {
    	 int a=10;
    	 int b=30;
    	 int c=a+b;
    	 System.out.println("Addition of Two numbers\n" +c);
    			 
     }
}
