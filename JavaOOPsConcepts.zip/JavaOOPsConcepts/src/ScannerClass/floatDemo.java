package ScannerClass;

import java.util.Scanner;

public class floatDemo {
	 public static void main(String args[])
	    {
		   Scanner sc=new Scanner(System.in);
		   System.out.println("Enter the number:");
		    float a= sc.nextFloat();
		    System.out.println(a);
		}
	
}
