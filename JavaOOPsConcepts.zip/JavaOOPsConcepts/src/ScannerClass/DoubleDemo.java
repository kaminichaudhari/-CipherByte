package ScannerClass;

import java.util.Scanner;

public class DoubleDemo {
	 public static void main(String args[])
	    {
		   Scanner sc=new Scanner(System.in);
		   System.out.println("Enter the number:");
		    double a= sc.nextDouble();
		    System.out.println(a);
		}
	

}
