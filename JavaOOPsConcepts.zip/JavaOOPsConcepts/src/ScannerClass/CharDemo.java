package ScannerClass;

import java.util.Scanner;

public class CharDemo {
	 public static void main(String args[])
	    {
		   Scanner sc=new Scanner(System.in);
		   System.out.println("Enter the number:");
		    char a= sc.next().charAt(0);
		    System.out.println(a);
		}
	}


