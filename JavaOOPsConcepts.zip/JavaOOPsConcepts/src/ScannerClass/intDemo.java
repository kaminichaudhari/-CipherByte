package ScannerClass;

import java.util.Scanner;

public class intDemo {
	 public static void main(String args[])
	    {
		   Scanner sc=new Scanner(System.in);
		   System.out.println("Enter the number:");
		    int a= sc.nextInt();
		    System.out.println(a);
		}
	}


