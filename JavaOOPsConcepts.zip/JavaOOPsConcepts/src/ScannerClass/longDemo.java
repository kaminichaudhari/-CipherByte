package ScannerClass;

import java.util.Scanner;

public class longDemo {
	 public static void main(String args[])
	    {
		   Scanner sc=new Scanner(System.in);
		   System.out.println("Enter the number:");
		    long a= sc.nextLong();
		    System.out.println(a);
		}
	}


