package ScannerClass;

import java.util.Scanner;

public class ScannerClass {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);// Scanner class is used to take input from user.
		System.out.print("Enter first number:");
		int a=sc.nextInt();
		System.out.print("Enter Second number:");
		int b=sc.nextInt();
		
		int c=a+b;
		System.out.print("Addition of two number is :"+c);
	}

}
