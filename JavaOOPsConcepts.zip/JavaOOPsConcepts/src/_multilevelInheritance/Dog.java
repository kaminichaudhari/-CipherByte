package _multilevelInheritance;

public class Dog extends Animal {
           void bark(){
	          System.out.println("the dog barks ");
         }
           public static void main(String args[]){
        	   Dog d=new Dog();
        	   d.eat();
        	   d.bark();
           }
}
