package _multilevelInheritance;

public class Animal {
	public void eat(){
		
		System.out.println("Animal eat food");
		
	}

}
