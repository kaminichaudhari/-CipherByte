package _multilevelInheritance;

public class puppy extends Dog{
	
	void weep(){
		System.out.println("puppy is weeping");
	}
	public static void main(String args[]){
		puppy p=new puppy();
		p.bark();//dog class
		p.eat();//animal class
		p.weep();//puppy class
	}

}
