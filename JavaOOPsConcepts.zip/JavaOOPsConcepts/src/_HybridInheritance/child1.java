package _HybridInheritance;

public class child1 extends Parent{
	void m2(){
		System.out.println("m2 method of child 1 class");
	}
	public static void main(String args[]){
		child1 c=new child1();
		c.m1();
		c.m2();
	}

}
