package _HybridInheritance;

public class childA extends Parent
{
          public static void main(String args[])
          {
        	  childA c1=new childA();
        	  c1.m1();
        	  
          }
}
