package _HybridInheritance;

public class child2 extends child1 {
	public static void main(String args[])
	{
		child2 c=new child2();
		c.m2();
	}
	

}
