package _HybridInheritance;

public class Parent {
	void m1(){
		System.out.println("m1 method of Parent class");
	}

}
