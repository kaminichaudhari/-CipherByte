package SuperKeyword;

public class Parent {
	public void m1(){//2) super with method
		System.out.println("m1 method of Parent class");
	}

}
