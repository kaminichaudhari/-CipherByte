package SuperKeyword;

public class child extends Parent {
	public void m1(){
		System.out.println("m1 method of child class");
		
	    super.m1();//2) super with method
	}
	public static void main(String args[]){
		child p=new child();
		p.m1();
		
	}

}
