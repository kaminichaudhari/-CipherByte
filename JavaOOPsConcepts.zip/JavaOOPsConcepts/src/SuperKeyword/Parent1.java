package SuperKeyword;

public class Parent1 {
	
	public Parent1(int a,String name){  //3)super with constructor
		System.out.println("Parent1  constructor of Parent1 class");
	}

}
