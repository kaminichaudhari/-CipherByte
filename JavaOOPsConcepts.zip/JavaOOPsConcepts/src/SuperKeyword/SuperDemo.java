package SuperKeyword;
/*Super Keyword:Super keyword refers to the object of super class.

It is used when we want to call the super class variable ,method and constructor through 
sub class object.
Whenever super class and sub class variable and method name both are same then it  can be used only.

To avoid confusion between super class and sub class variables and methods that have same name then 
we should use super keyword.*/

public class SuperDemo {
	int a=20;//1)Super with variable 

}
