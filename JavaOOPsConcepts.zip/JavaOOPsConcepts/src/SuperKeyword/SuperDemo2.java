package SuperKeyword;

public class SuperDemo2 extends SuperDemo {
	int a=50;
	public void Parent(){
		
		System.out.println(a);
		System.out.println(super.a);//1)super with variable
	}
	
	public static void main(String args[]){
		SuperDemo2 s=new SuperDemo2();
		s.Parent();
		
		
	}

}
