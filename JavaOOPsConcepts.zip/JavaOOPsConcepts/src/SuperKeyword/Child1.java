package SuperKeyword;

public class Child1 extends Parent1 {
	
	public  Child1(int a , int b){
		super(b, null);
		System.out.println("child1 constructor of child1 class");
		
		//3)Super with constructor
	}
	public static void main(String args[]){
		Child1 p=new Child1(10, 12);
		
	}
	

}
