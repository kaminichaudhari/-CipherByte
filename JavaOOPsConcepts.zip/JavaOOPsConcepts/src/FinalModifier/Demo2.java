package FinalModifier;

public class Demo2 extends Demo1{
	/*@Override
	public void m1(){//2) Final with method : if we use final with method then we cant override that method into child class.  
		System.out.println("m1 method of child class");
		
	}
	public static void main(String args[]){
		Demo2 d=new Demo2();
		d.m1();
		
	}*/

}
