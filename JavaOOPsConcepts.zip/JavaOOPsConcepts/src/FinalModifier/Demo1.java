package FinalModifier;
/* Final modifier is used for restriction purpose.
Final modifier we can use with
1)Final with variable
2)final with Method
3)Final with class

1)Final with variable: If we use final with variable then we cant reassign the value .*/
   /*public class Demo1 {
	
	 public static void main(String args[]){
		final int a = 90;
		System.out.println(a);

		a = 89;
		System.out.println(a);

		
	}*/
	
//2) Final with method : if we use final with method then we cant override that method into child class.
	
     /*   public class Demo1{
        final void m1(){
		System.out.println("m1 method of demo1 class");
	      }
        }
	*/

//3)Final with class: If we declare class as final then we cant extend that class into child class.
    /* public final class Demo1{
	  void m1(){
		  System.out.println("m1 method of Parent class");
	  }
      }*/

//4)Final parameters: Parameters cannot be reassigned within a method.

      public class Demo1{
    	  
    	  public void m1(  final int a){
    		  System.out.println(a);
    		//  a=65;
    		//  System.out.println(a);
    		  
    	  }
    	  public static void main(String args[]){
    		  Demo1 d=new Demo1();
    		  d.m1(11);
    	  }
    	  
      }


