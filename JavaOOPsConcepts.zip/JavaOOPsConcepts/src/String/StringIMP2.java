package String;

public class StringIMP2 {
	public static void main(String[] args) {
		 String s1="spring";
	     String s2="water";
	     String s3="fall";
	     
	     String s4=new String("Autum");
	     String s5=new String("summer");
	     
	     String s6=s1;
	     String s7=new String("water");
	     
	     System.out.println("comparing s1 and s6");
	     System.out.println(s6==s1);
	     System.out.println(s1.equals(s6));
	     
	     System.out.println("Comparing s7 and s2");
	     System.out.println(s7==s2);
	     System.out.println(s7.equals(s2));
	     
	}

}
