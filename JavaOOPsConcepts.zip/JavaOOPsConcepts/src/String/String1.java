package String;
//String is Immutable:-can't change values.
public class String1 {
	public static void main(String[] args) {
		String s= new String ("kamini");               //String
		s=s.concat("chaudhari");
		System.out.println(s);
		
		
		
		
		
	}

}
