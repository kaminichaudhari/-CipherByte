package String;

public class StringDemo {
	
	public static void main(String[] args) {
	/*	String fname="kamini";                    //1)Concatenation (Joining 2 strings)
		String lname="chaudhari";
		
	//	System.out.println(fname+" "+lname);
		
		String name = fname+" "+lname;
		System.out.println(name);
	*/
		
	/*	String fname="kamini";                    //2)Print length of a String
		String lname="chaudhari";
		
		String name=fname+" "+lname;
		System.out.println(name.length());
	*/
		 
		/* String fname="kamini";                  //3)Access characters of a string
		 String lname="chaudhari";
		 
		 String name=fname+" "+lname;
		 
		 for(int i=0;i<name.length();i++){
			 System.out.println(name.charAt(i));
		 }
		 */
		
		
	}

}
