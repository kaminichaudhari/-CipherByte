package String;
//String -its a special datatype
//String =Its a class helps to store multiple characters together..
//primitive are =int,byte,char,boolean,long short,double
public class StringImp {
	public static void main(String[] args) {
		//two ways to declare String object
		
		String s1="Hello world";                     //string initialization using literal
		String s2=new String("Hello java student");   //String object creation using new Keyword
		
		//String class Methods..
		
		System.out.println(s1.length());
		System.out.println(s2.length());
		System.out.println(s1.charAt(1));
		System.out.println(s1.toUpperCase());
		System.out.println(s2.toLowerCase());
		System.out.println(s1.contains("friends"));
		System.out.println(s1.contains("Hello"));
		System.out.println(s2.startsWith("H"));
		System.out.println(s1.startsWith("h"));
		System.out.println(s1.endsWith("ld"));
		System.out.println(s2.endsWith("Ent"));
		System.out.println(s1.concat(s2));//join to strings
		System.out.println(s1.equals(s2));
		System.out.println(s1.equalsIgnoreCase("Hello worlds" ));
		System.out.println();
		
	}
}