package String;
//StringBuffer is mutable- we can change object.and Thread Safe
public class StringBufferDemo {
	public static void main(String[] args) {
		StringBuffer sb=new StringBuffer("kamini");
	    sb.append("chaudhari");
	    System.out.println(sb);
		
	}

}
