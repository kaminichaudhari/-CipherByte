package String;

public class StringDemo2 {
	public static void main(String[] args) {
		String fname="kamini";
		String lname="chaudhari";
	
		if(fname.equals(lname)){
			
			System.out.println("They are different string");
		}
		
		else
		{
			System.out.println("They are different string");
		}
          
		
		//DO NOT USE == to check for string equality
		 //Gives correct answer here
		
		/*if(fname==lname){
        	  System.out.println("They are same string");
  		}
		
		else
		{
			System.out.println("They are different string");
		}
		*/
		
		//Gives incorrect answer here
		
		/*if(new String("kamini")==new String("kamini") ){          
			System.out.println("They are same string");            
		}
		else{
			System.out.println("They are differant string");
		}*/
	}

}
