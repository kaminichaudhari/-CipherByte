package String;

public class StringBuilderDemo2 {
	public static void main(String[] args) {
		StringBuilder s=new StringBuilder("kamini");
		System.out.println(s);
		
		System.out.println(s.charAt(0));
		
		s.setCharAt(0, 'Y');
		System.out.println(s);
		
		s.insert(0, 'y');
		System.out.println(s);
		
		s.delete(0, 1);
		System.out.println(s);
	}

}
