package String;
//String Builder- mutable-not thread safe.
public class StringBuilderDemo {
	public static void main(String[] args) {
		
		StringBuilder sb=new StringBuilder("Kamini");
		sb.append("chaudhari");
		System.out.println(sb);
		System.out.println(sb.capacity());
		System.out.println(sb.reverse());
		System.out.println(sb.length());
	}

}
