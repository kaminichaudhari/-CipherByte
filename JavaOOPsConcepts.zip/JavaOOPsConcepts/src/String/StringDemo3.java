package String;

public class StringDemo3 {
	public static void main(String[] args) {
		String s="student";
		s=s+"student";
	}

}
