package JavaClass;

public class classDemo1 {
	
	String animalName="Dog";
	
	public void eat(){
		System.out.println("Dog is eating");
	}
	public static void main(String args[])
	{
		classDemo1 a=new classDemo1();
		a.eat();
		
	}

}
