package JavaClass;

public class classDemo {
	 String Name="lion";                  //variable
	 
	 public void eat(){                   //Method
		 System.out.println("Lion is eating");
		 
	 }
	 public static void main(String args[])
	 {
	      classDemo c1=new classDemo();    //object
	      c1.eat();
	      
	 }
	 
	 

}
