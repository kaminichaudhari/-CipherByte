package ArithmeticOperator;

public class ArithmeticOperator {
	public static void main(String args[]){
		int a=20;
		int b=30;
		
		System.out.println("Addition of two numbers:"+ (a+b));
		System.out.println("Subtraction of two numbers:"+(a-b));
		System.out.println("division of two number:"+ (a/b));
		System.out.println("modulus of two number:"+ (a%b));
		System.out.println("multiplication of two number:"+ (a*b));
			
	}

}
