package ArithmeticOperator;

public class LogicalOperator {

	public static void main(String[] args) {
		
		int a=10;
		int b=5;
		
		System.out.println(a>b);
		System.out.println(a<b);
		
		System.out.println("***********Logical AND operator:(&&)***********");
		System.out.println((a>b)&&(a>b));//T T=T
		System.out.println((a>b)&&(a<b));//T F=F
		System.out.println((a<b)&&(a>b));//F T=F
		System.out.println((a<b)&&(a<b));//F F=F
		
		System.out.println("***********Logical OR operator:(||)***********");
		System.out.println((a>b)||(a>b));//T T=T
		System.out.println((a>b)||(a<b));//T F=T
		System.out.println((a<b)||(a>b));//F T=T
		System.out.println((a<b)||(a<b));//F F=F
		
		System.out.println("***********Logical NOT operator:(!)***********");

		System.out.println(!(a>b)); //TRUE = FALSE
		System.out.println(!(a<b));//FALSE =TRUE
		

	}

}
