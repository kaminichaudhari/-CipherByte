package ArithmeticOperator;

public class RelationalOperator 
{
         public static void main(String args[])
         {
        	 int a=10;
        	 int b=5;
        	  System.out.println(a<b);//less
        	  System.out.println(a>b);//greter
              System.out.println(a<=b);
              System.out.println(a>=b);
              System.out.println(a==b);
              System.out.println(a!=b);
         }
}
