package ArithmeticOperator;

public class TernaryOperator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10;
		int b=20;
		
		int result=(a>b)? a:b;
		System.out.println(result);
		
		/*if(a>b){
			System.out.println(a);
		}
		else
		{
			System.out.println(b);
		}*/

	}

}
