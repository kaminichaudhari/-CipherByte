package ArithmeticOperator;

public class IncrementOperator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10;
		System.out.println(a);
		
		a++;//Post Increment Operator
		System.out.println(a);
		
		++a;//Pre Increment operator
		System.out.println(a);
		/*int a=10;
		System.out.println(a);
		
		System.out.println(a++);
		System.out.println(a);*/
	}

}
