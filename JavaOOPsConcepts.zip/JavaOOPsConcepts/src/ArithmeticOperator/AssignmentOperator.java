package ArithmeticOperator;

public class AssignmentOperator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10;
		a=a+20;                //simple assignment
		System.out.println(a);
		
		int b=20;
		b+=30;                 //compund assignment
		System.out.println(b);
		
		int c=50;
		c*=20;
		System.out.println(c);
		
		int d=5;
		d/=20;
         System.out.println(d);
	}

}
