package com.shearise.atm.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.shearise.atm.entity.Account;
import com.shearise.atm.entity.Bank;
import com.shearise.atm.entity.Customer;

public class DummyData 
{
	public static void main(String[] args) 
	{
		EntityManager entityManager = MyConnection.getEntityManager();

	    EntityTransaction entityTransaction = entityManager.getTransaction();
	    
	   
	    Bank bank = new Bank();
	    bank.setIfscCode("MAHG0006003");
	    bank.setBankName("Maharatra");
	    bank.setAddress("vadali");
	  
	
	    Bank bank2 = new Bank();
        bank2.setIfscCode("C8IN028195");
	    bank2.setBankName("Central Bank");
	    bank2.setAddress("Shirpur");
	
	    Customer customer1 = new Customer();
	    customer1.setCustomerId("201101095");
	    customer1.setCustomerName("kamini");
	  
   	    customer1.setMobile("7620771918");
	    customer1.setDob(LocalDate.of(2003,06,05));
	    customer1.setAddress("Bamkheda");
	    customer1.setBank(bank);
	
	    Customer customer2 = new Customer();
	    customer2.setCustomerId("201101097");
	    customer2.setCustomerName("Kalyani");
	
	    customer2.setMobile("8669071401");
	    customer2.setDob(LocalDate.of(2003,7,24));
        customer2.setAddress("Dhule");
        customer2.setBank(bank);
	
	    Customer customer3 = new Customer();
	    customer3.setCustomerId("201101011");
	    customer3.setCustomerName("Rina");

	    customer3.setMobile("9156289665");
	    customer3.setDob(LocalDate.of(2003,02,22));
	    customer3.setAddress("Jalgon");
	    customer3.setBank(bank2);
	
	    Customer customer4 = new Customer();
	    customer4.setCustomerId("201101012");
	    customer4.setCustomerName("Vishakha");
	
	    customer4.setMobile("9892329298");
	    customer4.setDob(LocalDate.of(2002,12,23));
	    customer4.setAddress("mumbai");
	    customer4.setBank(bank2);
	
	    List<Customer> list = new ArrayList<>();
	    list.add(customer1);
	    list.add(customer2);
	    list.add(customer3);
	    list.add(customer4);

	    bank.setCustomers(list);
        bank2.setCustomers(list);
      
        Customer customer=new Customer();
        customer.setCustomerId("201101095");
	    customer.setCustomerName("kamini");
	    customer.setMobile("7620771918");
	    customer.setDob(LocalDate.of(2003,06,05));
	    customer.setAddress("Bamkheda");
	      
        Account account1 = new Account();
        account1.setAccountNo("12345678912l");
        account1.setAccountType("saving account");
        account1.setCurrentBalance(30000.00);
        account1.setAccountOpeningDate(LocalDate.of(2023,11,03));
        account1.setAccountStatus("activate");
        
        List<Customer>list1 = new ArrayList<>();
        list1.add(customer);
        account1.setCustomer(customer);
        
        List<Account>list2 = new ArrayList<>();
        list2.add(account1);
    //     ((Customer) list1).setAccount(list2);
        Customer customerFromList = list1.get(0);   // ✅ fetch first element
        customerFromList.setAccount(list2);   
        
	    entityTransaction.begin();
	    	entityManager.persist(bank);
	    	entityManager.persist(bank2);
	       //   entityManager.persist(customer);
	    	customer = entityManager.merge(customer); // ✅ Safe


	    	account1 = entityManager.merge(account1);

	    	
	    	

	    entityTransaction.commit();

	    System.out.println("...Add Records Successfully...");
	}
}
