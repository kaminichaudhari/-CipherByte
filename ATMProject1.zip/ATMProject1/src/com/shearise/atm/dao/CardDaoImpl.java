package com.shearise.atm.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.shearise.atm.entity.AtmCard;

public class CardDaoImpl implements CardDao{
	private EntityManager entityManager=MyConnection.getEntityManager();
	private EntityTransaction entityTransaction=entityManager.getTransaction();
	
	@Override
	public AtmCard findCardNo(String cardNo)
	{
		AtmCard  atmCard = entityManager.find(AtmCard.class,cardNo);
		return atmCard;
	}
	@Override
	public String updateCardStatus(AtmCard atmCard) 
	{
		atmCard=entityManager.find(AtmCard.class,atmCard.getCardNo());
		entityTransaction.begin();
			atmCard.setCardStatus("Blocked");
		entityTransaction.commit();
		return "your card is blocked";
	}
	@Override
	public String changePin(AtmCard atmCard,Integer newPin)
	{
		entityTransaction.begin();
		    atmCard.setCardPin(newPin);
		entityTransaction.commit();
		return "Card pin change successfully";
	}
}
