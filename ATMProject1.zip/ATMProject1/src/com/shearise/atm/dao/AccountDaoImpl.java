package com.shearise.atm.dao;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import com.shearise.atm.entity.Account;
import com.shearise.atm.entity.Transactions;

public class AccountDaoImpl implements AccountDao{
	EntityManager entityManager=MyConnection.getEntityManager();
	EntityTransaction entityTransaction=entityManager.getTransaction();
	
	@Override
	public Transactions deposit(Account account, Double amount) 
	{
		Transactions transactions=new Transactions();
		transactions.setTransactionDate(LocalDate.now());
		transactions.setTransactionTime(LocalTime.now());
		transactions.setTransactionType("CR");
		transactions.setAccount(account);
		transactions.setTransactionAmount(amount);;
        entityTransaction.begin();
	    account.setCurrentBalance(account.getCurrentBalance() + amount);
	    entityManager.persist(transactions);
        entityTransaction.commit();
		return transactions;
	}
	
	@Override
	public Double checkBalance(String accountNo)
	{
		Account account = entityManager.find(Account.class, accountNo);
        return account.getCurrentBalance();
	}
	
	@Override
	public Transactions withdraw(Account account, Double amount) 
	{
		Transactions transactions=new Transactions();
		transactions.setTransactionDate(LocalDate.now());
		transactions.setTransactionTime(LocalTime.now());
		transactions.setTransactionType("DR");
		transactions.setAccount(account);
		transactions.setTransactionAmount(amount);;
        entityTransaction.begin();
	      	account.setCurrentBalance(account.getCurrentBalance() - amount);
	      	entityManager.persist(transactions);
        entityTransaction.commit();
		return transactions;
	}

	@Override
	public List<Transactions> miniStatement(Account account) 
	{
		String jpql="SELECT t FROM Transactions t WHERE t.account.accountNo = ?1 ORDER BY t.transactionDate DESC ";
		Query query=entityManager.createQuery(jpql);
		query.setParameter(1,account.getAccountNo());
		query.setMaxResults(10);
		@SuppressWarnings("unchecked")
		List<Transactions> list=query.getResultList();
		return list;
	}

	@Override
	public List<Object[]> checkTotalWithdrawalLimitPerDay(Account account) 
	{
		String jpql="SELECT SUM(t.transactionAmount),COUNT(t) FROM Transactions t WHERE t.account.accountNo = ?1 AND t.transactionDate=?2 AND t.transactionType='DR'";
		Query query=entityManager.createQuery(jpql);
		query.setParameter(1,account.getAccountNo());
		query.setParameter(2,LocalDate.now());
		@SuppressWarnings("unchecked")
		List<Object[]> resultList= query.getResultList();
	    return resultList;
		
		
	}
}
