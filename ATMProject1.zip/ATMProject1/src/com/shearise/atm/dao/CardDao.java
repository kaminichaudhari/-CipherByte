package com.shearise.atm.dao;

import com.shearise.atm.entity.AtmCard;

public interface CardDao {
	AtmCard findCardNo(String cardNo);
    String updateCardStatus(AtmCard atmcard);
    String changePin(AtmCard atmCard,Integer newPin);
}
