package com.shearise.atm.validation;

public class MyValidation {
	public static Boolean checkCardlength(String cardNo){
		if (cardNo.length() != 16) {
            return false;
        }
		return true;
		
	}
	public static Boolean checkCardNo(String cardNo){
	
        for (int i = 0; i < cardNo.length(); i++) {
            if (!Character.isDigit(cardNo.charAt(i))) {
                return false;
            }
        }
		return true;
		
	}
	public static Boolean checkPinNo(String pin){
		if (pin.length() != 4) {
            return false;
        }
        for (int i = 0; i < pin.length(); i++) {
            if (!Character.isDigit(pin.charAt(i))) {
                return false;
            }
        }
		return true;
	}
	
	
   
}
