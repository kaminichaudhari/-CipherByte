package com.shearise.atm.service;

import java.util.List;


import com.shearise.atm.entity.Account;
import com.shearise.atm.entity.Transactions;

public interface AccountService 
{
	Double checkBalance(String accountNo);
	Transactions deposit(Account account, Double amount);
	Transactions withdraw(Account account, Double amount);
	List<Transactions> miniStatement(Account account);
	List<Object[]> checkTotalWithdrawalLimitPerDay(Account account);
}
