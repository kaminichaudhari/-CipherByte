package com.shearise.atm.service;

import com.shearise.atm.entity.AtmCard;

public interface CardService {
	AtmCard findCardNo(String cardNo);
	String updateCardStatus(AtmCard atmCard);
	String changePin(AtmCard atmCard,Integer newPin);
}
