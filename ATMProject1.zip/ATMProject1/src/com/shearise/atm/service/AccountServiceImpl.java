package com.shearise.atm.service;

import java.util.List;

import com.shearise.atm.dao.AccountDao;
import com.shearise.atm.dao.AccountDaoImpl;
import com.shearise.atm.entity.Account;
import com.shearise.atm.entity.Transactions;

public class AccountServiceImpl implements AccountService {
    
	private AccountDao accountDao;
	
    public AccountServiceImpl()
    {
    	accountDao=new AccountDaoImpl();
    }

	@Override
	public Double checkBalance(String accountNo) 
	{
		return accountDao.checkBalance(accountNo);
	}

	@Override
	public Transactions deposit(Account account, Double amount)
	{
		return accountDao.deposit(account, amount);
	}

	@Override
	public Transactions withdraw(Account account, Double amount) 
	{
		return accountDao.withdraw(account, amount);
	}

	@Override
	public List<Transactions> miniStatement(Account account)
	{
		return accountDao.miniStatement(account);
	}

	@Override
	public List<Object[]> checkTotalWithdrawalLimitPerDay(Account account) {
		
		return accountDao.checkTotalWithdrawalLimitPerDay(account);
		
	}
	
}
