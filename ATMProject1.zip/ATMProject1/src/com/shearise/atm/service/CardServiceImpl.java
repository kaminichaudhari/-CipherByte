package com.shearise.atm.service;

import com.shearise.atm.dao.CardDao;
import com.shearise.atm.dao.CardDaoImpl;
import com.shearise.atm.entity.AtmCard;

public class CardServiceImpl implements CardService {
	private CardDao cardDao;
	public CardServiceImpl()
	{
		cardDao= new CardDaoImpl();
	}
	@Override
	public AtmCard findCardNo(String cardNo) 
	{
		return cardDao.findCardNo(cardNo);
	}
	@Override
	public String updateCardStatus(AtmCard atmCard) 
	{
		return cardDao.updateCardStatus(atmCard);
	}
	@Override
	public String changePin(AtmCard atmCard,Integer newPin)
	{
		return cardDao.changePin(atmCard,newPin);
	}
	
}
