package com.shearise.atm.entity;

import java.time.LocalDate;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import lombok.Data;

@Entity
@Data
public class Account {
	@Id
	@Column(length = 16)
	private String accountNo;

	@Column(length = 20)
	private String accountType;

	private Double currentBalance;
	private LocalDate accountOpeningDate;

	@Column(length = 12)
	private String accountStatus;

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "customerId")
	private Customer customer;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "account")
	private List<AtmCard> atmCards;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "account")
	private List<Transactions> transactions;
}
