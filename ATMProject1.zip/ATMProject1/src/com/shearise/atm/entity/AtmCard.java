package com.shearise.atm.entity;

import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.Data;

@Entity
@Data
public class AtmCard {
	@Id
	@Column(length = 16)
	private String cardNo;
	private Integer cardPin;
	private Integer cvv;
	private LocalDate cardIssueDate;
	private LocalDate cardExpiryDate;

	@Column(length = 10)
	private String cardStatus;

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "accountNo")
	private Account account;

}
