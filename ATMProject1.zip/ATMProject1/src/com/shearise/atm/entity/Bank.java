package com.shearise.atm.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import lombok.Data;

@Entity
@Data
public class Bank {
	@Id
	@Column(length=30)
	private String ifscCode;
	@Column(length=30)
	private String bankName;
	@Column(length=5)
	private String branchCode;
	@Column(length = 15)
	private String address;
	
	@OneToMany(cascade=CascadeType.ALL,mappedBy="bank")
	private List<Customer> customers;
	
}
