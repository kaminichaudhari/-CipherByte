package com.shearise.atm.entity;


import java.time.LocalDate;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import lombok.Data;

@Entity
@Data
public class Customer 
{
	@Id
	@Column(length=12)
	private String customerId;
	
	@Column(length=30)
	private String customerName;
	
	@Column(length=50)
	private String Address;
	//String Address;
	@Column(length=50)
	private String mobile;
	
	@Column(length=10)
	private String customerGender;
	
	private LocalDate dob;
	
	@Column(length=10)
	private String  mobno;
	
	@Column(length=10)
	private String  panCardNo;
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="ifscCode")
    private Bank bank;
	
	@OneToMany(cascade=CascadeType.ALL,mappedBy="customer")
	private List<Account> account;
	
}
